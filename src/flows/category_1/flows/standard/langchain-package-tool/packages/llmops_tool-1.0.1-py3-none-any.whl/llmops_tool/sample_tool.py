from promptflow import tool


@tool(
    name="sample_tool",
    description="This is a sample tool",
)
def langchain_chain(
    query: str) -> str:
    return query
